import requests
from bs4 import BeautifulSoup
import datetime
from datetime import timedelta
import pandas as pd
import time
import pandas as pd
import re
import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from IPython.display import Image, display
import matplotlib as mpl
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
from matplotlib.colors import LinearSegmentedColormap
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
plt.rcParams.update({'font.size': 22})


def scrape_stats():
    """Scrape NBA data from the Basketball Reference website"""
    
    df_pergame = pd.DataFrame() #Get Per Game Stats
    for year in range(1950, 2022, 1): # NBA seasons
        url = f"https://www.basketball-reference.com/leagues/NBA_{year}.html"
        response = requests.get(url)
        soup = BeautifulSoup(response.text)
        pergame = soup.find('div', {'id': 'switcher_per_game_team-opponent'})

        pergameheaders = [th.text for th in pergame.find('tr').find_all('th')]
        pergameheaders = pergameheaders[1:]

        pergamerows = pergame.find_all('tr')[1:]
        team_pergamestats = [[td.text for td in pergamerows[i].find_all('td')]
                    for i in range(len(pergamerows))]

        df_stats = pd.DataFrame(team_pergamestats, columns = pergameheaders)
        df_stats['year'] = year
        df_pergame = pd.concat([df_pergame, df_stats]) 
        time.sleep(1)
    df_pergame.to_csv('NBA_pergame.csv', index=False)
    
    df_totalstats = pd.DataFrame() #Get Total Stats
    for year in range(1950, 2022, 1): # NBA seasons
        url = f"https://www.basketball-reference.com/leagues/NBA_{year}.html"
        response = requests.get(url)
        soup = BeautifulSoup(response.text)

        totalstats = soup.find('div', {'id': 'switcher_totals_team-opponent'})
        totalstatsheaders = [th.text for th in totalstats.find('tr').\
                             find_all('th')]
        totalstatsheaders = totalstatsheaders[1:]

        totalstatsrows = totalstats.find_all('tr')[1:]
        team_totalstats = [[td.text for td in totalstatsrows[i].\
                            find_all('td')]
                    for i in range(len(totalstatsrows))]

        df_stats_2 = pd.DataFrame(team_totalstats,
                                  columns = totalstatsheaders)
        df_stats_2['year'] = year
        df_totalstats = pd.concat([df_totalstats, df_stats2]) 
        time.sleep(1)
    df_totalstats.to_csv('NBA_totalstats.csv', index=False)

    df_possstats = pd.DataFrame() #Get the Stats Per 100 Possessions
    for year in range(1974, 2022, 1): # NBA seasons, data until 1974 only
        url = f"https://www.basketball-reference.com/leagues/NBA_{year}.html"
        response = requests.get(url)
        soup = BeautifulSoup(response.text)

        possstats = soup.find('div', 
                              {'id': 'switcher_per_poss_team-opponent'})
        possstatsheaders = [th.text for th in possstats.\
                            find('tr').find_all('th')]
        possstatsheaders = possstatsheaders[1:]

        possstatsrows = possstats.find_all('tr')[1:]
        team_possstats = [[td.text for td in possstatsrows[i].find_all('td')]
                    for i in range(len(possstatsrows))]

        df_stats_3 = pd.DataFrame(team_possstats, columns = possstatsheaders)
        df_stats_3['year'] = year
        df_possstats = pd.concat([df_possstats, df_stats3]) 
        time.sleep(1)
    df_possstats.to_csv('NBA_possstats.csv', index=False)
    
    
    df_advstats = pd.DataFrame() # Get the Advanced Stats
    for year in range(1950, 2022, 1): # NBA seasons, data until 1974 only
        url = f"https://www.basketball-reference.com/leagues/NBA_{year}.html"
        response = requests.get(url)
        soup = BeautifulSoup(response.text)

        advstats = soup.find('div', {'id': 'div_advanced-team'})
        advstatsheaders = [th.text for th in advstats.find_all\
                           ('tr', limit = 2)[1].find_all('th')]
        advstatsheaders = advstatsheaders[1:]

        advstatsrows = advstats.find_all('tr')[2:]
        team_advstats = [[td.text for td in advstatsrows[i].find_all('td')]
                    for i in range(len(advstatsrows))]

        df_stats_4 = pd.DataFrame(team_advstats, columns = advstatsheaders)
        df_stats_4['year'] = year
        df_advstats = pd.concat([df_advstats, df_stats4])
    df_advstats.columns = ['Team', 'Age', 'W', 'L', 'PW', 'PL', 'MOV', 'SOS',
                           'SRS', 'ORtg', 'DRtg', 'NRtg', 'Pace', 'FTr',
                           '3PAr', 'TS%', ' ', 'eFG%_offense', 'TOV%_offense',
                           'ORB%_offense', 'FT/FGA_offense', ' ',
                           'eFG%_defense', 'TOV%_defense', 'DRB%_defense',
                           'FT/FGA_defense', ' ', 'Arena', 'Attend.',
                           'Attend./G', 'year']
    cols = [i for i,j in enumerate(df_advstats.columns) if str(j) == ' ']
    df_advstats.drop(df_advstats.columns[cols],axis=1,inplace=True)
    df_advstats.to_csv('NBA_advstats.csv', index=False)
    
    
    #Get the Shooting Stats
    df_shootstats1997 = pd.DataFrame()
    for year in range(1997, 2002, 1): 
        # NBA seasons 1997 to 2001 since table columns changed
        url = f"https://www.basketball-reference.com/leagues/NBA_{year}.html"
        response = requests.get(url)
        soup = BeautifulSoup(response.text)

        shootstats = soup.find('div', {'id': 'div_shooting-team'})
        shootstatsheaders = [th.text.strip() for th in shootstats.find_all\
                             ('tr', limit = 2)[1].find_all('th')]
        shootstatsheaders = shootstatsheaders[1:]

        shootstatsrows = shootstats.find_all('tr')[2:]
        team_shootstats = [[td.text for td in shootstatsrows[i].\
                            find_all('td')]
                    for i in range(len(shootstatsrows))]

        df_stats_5 = pd.DataFrame(team_shootstats,
                                  columns = shootstatsheaders)
        df_stats_5['year'] = year
        df_shootstats1997 = pd.concat([df_shootstats1997, df_stats5])
    df_shootstats1997.columns = ['Team', 'G', 'MP', 'FG%', 'Dist.', '',
                                 '2P_%FGA','0-3_%FGA', '3-10_%FGA', 
                                 '10-16_%FGA','16-3pt_%FGA', '3P_%FGA', '', 
                                 '2P_FG%', '0-3_FG%', '3-10_FG%', '10-16_FG%',
                                 '16-3pt_FG%','3P_FG%', '', '2P_%FGAst',
                                 '3P_%FGAst', '', '%FGA_Dunks', 'Md._Dunks', 
                                 '', '%3PA_Corner','3P%_Corner', '',
                                 'Att._Heaves','Md._Heaves','year']
    cols = [i for i,j in enumerate(df_shootstats1997.columns) if str(j) == '']
    df_shootstats1997.drop(df_shootstats1997.columns[cols],axis=1,
                           inplace=True)

    df_shootstats2002 = pd.DataFrame()
    for year in range(2002, 2022, 1): 
        # NBA seasons 2002 onwards since table columns changed
        url = f"https://www.basketball-reference.com/leagues/NBA_{year}.html"
        response = requests.get(url)
        soup = BeautifulSoup(response.text)

        shootstats = soup.find('div', {'id': 'div_shooting-team'})
        shootstatsheaders = [th.text.strip() for th in shootstats.find_all\
                             ('tr', limit = 2)[1].find_all('th')]
        shootstatsheaders = shootstatsheaders[1:]

        shootstatsrows = shootstats.find_all('tr')[2:]
        team_shootstats = [[td.text for td in shootstatsrows[i].\
                            find_all('td')]
                    for i in range(len(shootstatsrows))]

        df_stats_6 = pd.DataFrame(team_shootstats,
                                  columns = shootstatsheaders)
        df_stats_6['year'] = year
        df_shootstats2002 = pd.concat([df_shootstats2002, df_stats_6]) 
    df_shootstats2002.columns = ['Team', 'G', 'MP', 'FG%', 'Dist.', '', 
                                 '2P_%FGA', '0-3_%FGA', '3-10_%FGA', 
                                 '10-16_%FGA', '16-3pt_%FGA', '3P_%FGA', '', 
                                 '2P_FG%','0-3_FG%', '3-10_FG%', '10-16_FG%',
                                 '16-3pt_FG%','3P_FG%', '', '2P_%FGAst',
                                 '3P_%FGAst', '','%FGA_Dunks', 'Md._Dunks', 
                                 '', '%FGA_Layups','Md._Layups', '',
                                 '%3PA_Corner', '3P%_Corner',
                                 '', 'Att._Heaves', 'Md._Heaves', 'year']
    cols = [i for i,j in enumerate(df_shootstats2002.columns) if str(j) == '']
    df_shootstats2002.drop(df_shootstats2002.columns[cols],
                           axis=1,inplace=True)

    df_shootstats_allyears = pd.concat([df_shootstats2002, df_shootstats1997],
                                       axis=0, ignore_index=True)
    df_shootstats_allyears.to_csv('NBA_shootstats.csv', index=False)
    
    
    
    df_champions = pd.DataFrame()
    for year in range(1950, 2022, 1): 
        url = f"https://www.basketball-reference.com/leagues/NBA_{year}.html"
        response = requests.get(url)
        soup = BeautifulSoup(response.text)
        champions = [i.text for i in soup.select\
                     ("#meta > div:nth-child(2) > p:nth-child(3) > a")][0]
        series = pd.Series({year : champions})
        df_champions = pd.concat([df_champions, series])
    df_champions = df_champions.reset_index()
    df_champions.columns = ['Year', 'Champion']
    df_champions.to_csv('NBA_champions.csv', index = False)

    
def get_teams():
    """Returns a list of the associated team names per NBA franchise"""
    
    url = "https://www.basketball-reference.com/teams/"
    response = requests.get(url)
    soup = BeautifulSoup(response.text)

    teams = soup.find_all('tbody')[0]
    team = ''
    names = {}
    for i in teams('tr'):

        if i['class'][0] == 'full_table':
            team = i.find('a').text
            names[i.find('a').text] = team
        else:
            names[i.find('th').text] = team
            
    return names


def clean_df():
    """Cleans the DataFrames for EDA"""
    
    df_pergame = pd.read_csv('NBA_pergame.csv')
    df_totalstats = pd.read_csv('NBA_totalstats.csv')
    df_possstats = pd.read_csv('NBA_possstats.csv')
    df_advstats = pd.read_csv('NBA_advstats.csv').drop(['Attend.',
                                                        'Attend./G'],axis=1)
    df_champions = pd.read_csv('NBA_champions.csv')
    df_shootstats_allyears = pd.read_csv('NBA_shootstats.csv')
    
    #Per Game Stats
    df_pergame_clean = df_pergame.dropna().copy()
    df_pergame_clean['Team'] = df_pergame_clean['Team'].str.replace('*','')

    team_list = []
    team_orig = df_pergame_clean['Team'].tolist()

    for i in team_orig:
        if i == 'League Average':
            team_list += [i]

        elif i == 'New Orleans/Oklahoma City Hornets':
            team_list += [i]

        else:
            team_list += [names[i]]
            
    df_pergame_clean.to_csv('NBA_pergame_clean.csv', index=False)

    #Total Stats
    df_totalstats_clean = df_totalstats.dropna().copy()
    df_totalstats_clean['Team'] = df_totalstats_clean['Team'].str.\
    replace('*','')

    team_list = []
    team_orig = df_totalstats_clean['Team'].tolist()

    for i in team_orig:
        if i == 'League Average':
            team_list += [i]

        elif i == 'New Orleans/Oklahoma City Hornets':
            team_list += [i]

        else:
            team_list += [names[i]]

    df_totalstats_clean['Team'] = team_list

    df_pergame_clean['Team'] = team_list

    df_totalstats_clean.to_csv('NBA_totalstats_clean.csv', index=False)

    #Stats Per 100 Possessions

    df_possstats_clean = df_possstats.dropna().copy()
    df_possstats_clean.drop_duplicates(subset=['Team','year'],inplace=True)
    df_possstats_clean['Team'] = df_possstats_clean['Team'].str.\
    replace('*','')

    team_list = []
    team_orig = df_possstats_clean['Team'].tolist()

    for i in team_orig:
        if i == 'League Average':
            team_list += [i]

        elif i == 'New Orleans/Oklahoma City Hornets':
            team_list += [i]

        else:
            team_list += [names[i]]

    df_possstats_clean['Team'] = team_list

    df_possstats_clean.to_csv('NBA_possstats_clean.csv', index=False)
    
    #Champions

    df_champions_clean = df_champions.dropna().copy()
    df_champions_clean['Champion'] = df_champions_clean['Champion'].str.\
    replace('*','')

    team_list = []
    team_orig = df_champions_clean['Champion'].tolist()

    for i in team_orig:
        if i == 'League Average':
            team_list += [i]

        elif i == 'New Orleans/Oklahoma City Hornets':
            team_list += [i]

        else:
            team_list += [names[i]]

    df_champions_clean['Champion'] = team_list
    
    df_champions_clean.to_csv('NBA_champions_clean.csv', index=False)

    #Advanced Stats

    df_advstats_clean = df_advstats.drop(['Arena'],axis=1).copy()
    df_advstats_clean = df_advstats_clean.dropna().copy()
    df_advstats_clean['Team'] = df_advstats_clean['Team'].str.replace('*','')

    team_list = []
    team_orig = df_advstats_clean['Team'].tolist()

    for i in team_orig:
        if i == 'League Average':
            team_list += [i]

        elif i == 'New Orleans/Oklahoma City Hornets':
            team_list += [i]

        else:
            team_list += [names[i]]

    df_advstats_clean['Team'] = team_list

    df_advstats_clean.to_csv('NBA_advstats_clean.csv', index=False)


def combine_features_df():
    """Integrates all the necessary features for processing and analysis"""
    df_champions_clean = pd.read_csv('NBA_champions_clean.csv')
    df_advstats_clean = pd.read_csv('NBA_advstats_clean.csv')
    df_possstats_clean =  pd.read_csv('NBA_possstats_clean.csv')
    
    drop_text1 = 'W L PW PL MOV SOS SRS TOV%_offense ORB%_offense '\
    'FT/FGA_offense TOV%_defense DRB%_defense FT/FGA_defense'
    drop_cols1 = drop_text1.split()
    df_champions_clean["team_id"] = df_champions_clean["Champion"] +\
    "-" + df_champions_clean["Year"].astype(str)
    df_champions_clean["champion_flag"] = 1

    df_final = df_possstats_clean.merge(df_advstats_clean)
    df_final["team_id"] = df_final["Team"] + "-" +\
    df_final["year"].astype(str)
     #drop seasons with only 50 games played
    df_final.drop(df_final[df_final['G'] == 50].index, inplace = True) 
   
    merged_final = pd.merge(left=df_final,
                            right=df_champions_clean[["champion_flag",
                                                      "team_id"]],
                            how='left', left_on='team_id', right_on='team_id') 
    merged_final.fillna(0, inplace=True)
    display(merged_final.head())
    merged_final = merged_final.drop(drop_cols1, axis=1).copy() 
    merged_final.to_csv('NBA_merged_df.csv', index = False)


def plot_boxscore():
    """Plot the trend of total box score statistics over the years"""
    fig = plt.figure(figsize = (15, 8)) 
    df = pd.read_csv('NBA_totalstats_clean.csv').dropna()
    df = df[df['Team'] != 'League Average']
    plt.rcParams.update({'font.size': 15})
    df_year = df.groupby('year')['TRB', 'AST', 'STL', 'BLK','TOV', 
                                 'PF', 'PTS'].sum().astype(int)
    plt.plot(df_year.index, df_year.TRB, label = "Rebounds")
    plt.plot(df_year.index, df_year.AST, label = "Assists")
    plt.plot(df_year.index, df_year.STL, label = "Steals")
    plt.plot(df_year.index, df_year.BLK, label = "Blocks")
    plt.plot(df_year.index, df_year.TOV, label = "Turnovers")
    plt.plot(df_year.index, df_year.PF, label = "Personal Fouls")
    plt.plot(df_year.index, df_year.PTS, label = "Points")
    plt.xlabel("Year")
    plt.title("NBA Total Box Score Statistics Per Season")
    plt.legend()
    plt.show()

    
def plot_total_champion():
    """Plot teams with number of championships"""
    df_champions = pd.read_csv('NBA_champions_clean.csv')
    fig = plt.figure(figsize = (15, 8)) 
    plt.bar(df_champions.Champion.value_counts().index, 
            df_champions.Champion.value_counts(), 
            color ='red', width = 0.4)
    plt.xticks(rotation = 45, ha = 'right')
    plt.xlabel("NBA Teams")
    plt.ylabel("No. of Championships")
    plt.title("The Boston Celtics is the champion among champions.")
    plt.show()
    

def plot_decade_champion():
    """Plot teams with number of championships per decade"""
    df_champions = pd.read_csv('NBA_champions_clean.csv')
    df_group = df_champions.groupby([(df_champions.Year//10)*10, 
                               'Champion'],as_index = False).size()
    df_renamed = df_group.rename(columns={'Year': 'Decade'})
    df_pivot = pd.pivot_table(df_renamed, 'size', 'Champion', 'Decade',
                        aggfunc='sum', margins=True)
    df_pivot.sort_values('All', ascending=False,inplace=True)
    df_clean = df_pivot.drop('All').fillna(0).astype(int).rename(
        columns={'All': 'All Time'}).copy()

    fig = plt.figure(figsize = (20, 10)) 
    plt.imshow(df_clean, cmap=plt.cm.afmhot_r, vmax=20, aspect=0.4)
    plt.yticks(range(len(df_clean)), df_clean.index)
    plt.xticks(range(df_clean.shape[1]), df_clean.columns);
    ax = plt.gca()
    ax.tick_params(axis="x", bottom=False, top=False, pad=-1,
                   labelbottom=False, labeltop=True)
    ax.tick_params(axis="y", left=False, labelleft=True, pad=2)
    for col, year in enumerate(df_clean.columns):
        for i in range(19):
            r = df_clean.iloc[i, col]
            plt.text(col, i, r, va='center', ha='center', fontsize=10,
                     color='#bc3c00' if r < 5 else '#ffc242')
    plt.suptitle("The NBA League is more competitive in recent decades.", 
                 fontweight='heavy', y=0.97)
    plt.title("Championships won by the decade", fontweight='heavy')
    plt.gcf().set_dpi(200)
    plt.show()

    
def df_decade_compare():
    """Return 1 row of advanced statistics dataset with championship label"""
    df_champ = pd.read_csv('NBA_champions_clean.csv').copy()
    df_champ = df_champ[['team_id', 'champion_flag']]
    df_champ2 = pd.read_csv('NBA_advstats_clean.csv').copy()

    df_champ2 = df_champ2[df_champ2['Team'] != 'League Average']
    df_champ2["team_id"] = df_champ2["Team"] + "-" +\
    df_champ2["year"].astype(str)
    df_merged = df_champ2.merge(df_champ, on='team_id', how='left')
    df_merged['champion_flag'] = df_merged['champion_flag'].fillna(0).\
    astype(int)
    df_decade_compare = df_merged.groupby([(df_merged.year//10)*10,
                                           'champion_flag']) \
    ['Age', 'ORtg','DRtg',  'Pace', 'FTr', '3PAr', 'TS%', 'eFG%_offense',
       'TOV%_offense', 'ORB%_offense', 'FT/FGA_offense', 'eFG%_defense',
       'TOV%_defense', 'DRB%_defense', 'FT/FGA_defense'].mean().dropna() 
    df_decade_compare.index.names = ['decade', 'champion_flag']
    return df_decade_compare
    
    
def df_decade_bool():
    """DataFrame comparing championship and non-championship teams"""
    df = df_decade_compare()
    df_decade_bool = (df.xs(1, level="champion_flag") > df.xs(0, 
                                                    level="champion_flag"))
    df_decade_bool = df_decade_bool.T
    df_decade_bool['All_Time_Rank'] = df_decade_bool.sum(axis = 1)
    df_decade_bool['All_Time_Rank'] = df_decade_bool['All_Time_Rank'] \
        .rank(axis=0, ascending=False, method = 'min').astype(int)
    df_decade_bool = df_decade_bool.sort_values(by=['All_Time_Rank'])
    return df_decade_bool


def df_decade_bool_plot():
    """Plot DataFrame comparing championship and non-championship team"""
    df_decade = df_decade_compare()
    df_decade_bool = (df_decade.xs(1, level="champion_flag") > df_decade.xs(0,
                                                level="champion_flag"))
    df_decade_bool.index.name = None
    df_decade_bool = df_decade_bool.T
    df_decade_bool = df_decade_bool.sort_values(by=[1980], ascending = False)
    f, ax = plt.subplots(figsize=(10, 20))
    colors = ["grey", "red"] 
    cmap = LinearSegmentedColormap.from_list('Custom', colors, len(colors))
    _ = sns.heatmap(df_decade_bool, cmap=cmap,square=True,  linewidths=.5, 
                    cbar_kws={"shrink": .5})
    colorbar = ax.collections[0].colorbar
    colorbar.set_ticks([0.25,0.75])
    colorbar.set_ticklabels(['Non-Championship teams better than Championship' 
                             ' teams', 
                             'Championship teams better than '
                             'non-championship teams'])
    ax.tick_params(axis="x", bottom=False, top=False, pad=-1,
                   labelbottom=False, labeltop=True)
    ax.tick_params(axis="y", left=False, labelleft=True, pad=2)
    plt.suptitle("Championship teams are older in age and are better in "
                 "rebounds, total shooting, and offensive in nature." 
                 , y=0.93, fontweight = 'heavy')
    plt.title("Factors that make Championship teams better (in decades)", 
              fontweight='heavy');

    
def plot_play_styles(stat):
    """Plot the statistics depending on the stat being compared
    
    Parameters
    ----------
    stat : str
        A comparative statistic or ratio. Can be 2v3_og1, 2v3_og2, 2v3, or 
    3pt.
    
    Returns
    -------
    None 
        If no stat or an invalid stat is provided
    """
    df_main = pd.read_csv('NBA_merged_df.csv')
    df_style = df_main[['Team','3P', '3PA', '3P%', '2P',\
                        '2PA','2P%','Pace','year']]
    df_ = pd.DataFrame([]) #placeholder df
    lst3PA = []
    lst2PA = []
    lst3Pct = []
    lstPace = []
    for i in df_style.year.unique():
        lst3PA += [df_style[df_style['year']==i]['3PA'].mean()]
        lst2PA += [df_style[df_style['year']==i]['2PA'].mean()]
        lst3Pct += [df_style[df_style['year']==i]['3P%'].mean()]
        lstPace += [df_style[df_style['year']==i]['Pace'].mean()]

    df_3PA = df_.append(lst3PA)
    df_3PA.columns = ['3-Point Attempts']
    df_3PA['Year'] = df_style.year.unique()
    df_2PA = df_.append(lst2PA)
    df_2PA.columns = ['2-Point Attempts']
    df_2PA['Year'] = df_style.year.unique()
    df_3Pct = df_.append(lst3Pct)
    df_3Pct.columns = ['3-Pt Shooting Pct.']
    df_3Pct['Year'] = df_style.year.unique()
    df_Pace = df_.append(lstPace)
    df_Pace.columns = ['Pace']
    df_Pace['Year'] = df_style.year.unique()

    df_3PA.set_index('Year',inplace=True)
    df_2PA.set_index('Year',inplace=True)
    df_3Pct.set_index('Year',inplace=True)
    df_Pace.set_index('Year',inplace=True)
    
    df_combined = pd.concat([df_3PA,df_2PA,df_3Pct],axis=1)
    df_combined_norm = (df_combined - 
                        df_combined.mean(axis=0)) / df_combined.std(axis=0)
    df_combined['2v3_ratio'] = df_combined['3-Point Attempts']/(
        df_combined['2-Point Attempts'] + df_combined['3-Point Attempts'])
    
    if stat == 'norm':
        return df_combined_norm
    
    if stat == '2v3_og1':
        df_combined[['3-Point Attempts','2-Point Attempts']].\
        plot(title='The average volume of 2-point shots taken by teams '
             'decreased in favor of more 3-point shots',
             figsize=(15,10),
             ylabel='Volume',
             color=['red','blue']);
        
        
    if stat == '2v3_og2':
        df_combined['2v3_ratio'].\
        plot(title='The ratio of 3-pointers taken by teams relative to their '
             'total shots significantly increased '
             'in the last 40 years',
             figsize=(15,10),
             ylabel='Ratio',
             color=['red','blue']);
    
    if stat == '2v3':
        df_combined_norm[['3-Point Attempts','2-Point Attempts']].\
        plot(title='The normalized volume of average 3-pointers attempted '
             'surpassed the normalized volume of average 2-pointers attempted'
             ' after 2000',
             figsize=(20,10),
             ylabel='Normalized Volume',
             color=['red','blue']);
        
    if stat == '3pt':
        df_combined_norm[['3-Point Attempts','3-Pt Shooting Pct.']].\
        plot(title='NBA teams have been shooting more 3-pointers with'
             ' a plateauing increase in accuracy',
             figsize=(15,10),
             ylabel='Normalized Volume',
             color=['red','blue']);
    else:
        return None
        
        
def plot_top_teams(stat):
    """Plots the comparison of top teams depending on stat called
    
    Parameters
    ----------
    stat : str
        A comparative statistic. Can be off, def, champ1, or
    champ2.
    
    Returns
    -------
    None 
        If no stat or an invalid stat is provided
    """
    df_main = pd.read_csv('NBA_merged_df.csv')
    df_play = df_main[['Team','ORtg','DRtg','year',
                   'champion_flag','team_id']].copy()

    df_ = pd.DataFrame([]) #placeholder df for defense
    lst = []
    for i in df_play.year.unique():
        min_ = df_play[df_play['year']==i]['DRtg'].min() 
        df = df_play[(df_play['DRtg']==min_) & (df_play['year']==i)]
        lst += [[df.Team.values[0],df.ORtg.values[0],df.DRtg.values[0],\
                 df.year.values[0],df.champion_flag.values[0],
                 df.team_id.values[0]]]
    df_def = df_.append(lst)
    df_def.columns = ['Team','ORtg','DRtg','year','champion_flag','team_id']
    df_def['flag'] = 'Defensive Teams'
    
    df_2 = pd.DataFrame([]) #placeholder df for offense
    lst2 = []
    for i in df_play.year.unique():
        max_ = df_play[df_play['year']==i]['ORtg'].max() 
        df = df_play[(df_play['ORtg']==max_) & (df_play['year']==i)]
        lst2 += [[df.Team.values[0],df.ORtg.values[0],df.DRtg.values[0],\
                 df.year.values[0],df.champion_flag.values[0],
                  df.team_id.values[0]]]
    
    df_off = df_2.append(lst2)
    df_off.columns = ['Team','ORtg','DRtg','year','champion_flag','team_id']
    df_off['flag'] = 'Offensive Teams'
    
    df1 = df_off['champion_flag'].value_counts().reset_index().\
    rename(columns={'champion_flag' : 'Offensive Teams'}).copy()
    df1_t = df1.transpose().reset_index().iloc[1:2]
    df2 = df_def['champion_flag'].value_counts().reset_index().\
    rename(columns={'champion_flag' : 'Defensive Teams'}).copy()
    df2_t = df2.transpose().reset_index().iloc[1:2]
    df_style = pd.merge(df1_t, df2_t,how='outer')
    df_style.rename(columns={'index' : 'Team Count', 0 : 'Not A Champion',
                             1 : 'Champion'},inplace=True)
    df_style.set_index('Team Count',inplace=True)
    combined_df = pd.merge(df_off,df_def,how='outer')    
   
    
    if stat == 'off':
        df_off_ = df_off['Team'].value_counts().head().reset_index()
        df_off_.rename(columns={'index' : 'Team', "Team" : 'Frequency'},
                      inplace=True)
        display(df_off_)
        
        df_off['Team'].value_counts().plot.bar(
            figsize=(20,10),
            fontsize=22,
            xlabel='Team',
            ylabel='Frequency',
            rot = 45,
            color=['blue']);
        plt.xlabel('NBA Teams',fontsize=22)
        plt.ylabel('Frequency',fontsize=22)
        plt.xticks(rotation = 45, ha = 'right')
        plt.suptitle(t='The Lakers franchise'
                ' has led the league'
                ' in offense the most times'
                ' in the last '
                '40 years',fontsize=22)
       

    if stat == 'def':
        df_def_ = df_def['Team'].value_counts().head().reset_index()
        df_def_.rename(columns={'index' : 'Team', "Team" : 'Frequency'},
              inplace=True)
        display(df_def_)
        
        df_def['Team'].value_counts().plot.bar(
            figsize=(20,10),
            fontsize=22,
            xlabel='NBA Team',
            ylabel='Frequency',
            rot = 45,
            color=['red']);
        plt.xticks(rotation = 45, ha = 'right')
        plt.xlabel('NBA Teams',fontsize=22)
        plt.ylabel('Frequency',fontsize=22)
        plt.suptitle(t='The Spurs franchise'
                ' has led the league'
                ' in defense the most times'
                ' in the last '
                '40 years',fontsize=22)
        

    if stat == 'champ1':
        df_style.plot.bar(title='The best offensive and defensive teams'
                        ' are not always champions',rot=0,
                          ylabel='Team Count',
                          color=['blue', 'red'],figsize=(15,10));
        plt.xlabel('',color='w')
    
    if stat == 'champ2':
        combined_df.groupby('flag')['champion_flag'].sum().\
            plot.bar(title='Generally, the best offensive teams'
                          ' win more championships',
                          ylabel='Championships Won',
                          rot=0,color=['red','blue'],
                          figsize=(15,10));
        plt.xlabel('',color='w')
    else:
        return None
           
        
def pca(X):
    """Perform principal component analysis on a matrix
    
    Parameters
    ----------
    X : numpy array
        The standardized features of the dataset
    
    Returns
    -------
    X_new : numpy array
        The new matrix 
        
    w : numpy array
        The new coordinate system
        
    variance_explained : numpy array
        The variance explained
    """
    A = X - X.mean(axis=0)
    covar = np.cov(A.T)
    eigval, eigvec = np.linalg.eig(covar)
    eigsort = eigval.argsort()[::-1]   
    eigval = eigval[eigsort]
    w = eigvec[:,eigsort]
    X_new = np.dot(A, w)
    variance_explained = eigval/sum(eigval)
    return X_new, w, variance_explained


def var_explained(x1):
    """Plot variance explained per principal component
    
    Parameters
    ----------
    x1 : numpy array
        The standardized features of the dataset
    """
    plt.figure(figsize=(12,7))
    X_new, w, variance_explained = pca(x1)
    plt.plot(range(1, len(variance_explained)+1), variance_explained, 'o-', 
             c = 'red')
    plt.ylim(0,1)
    plt.xlabel('PC')
    plt.ylabel('variance explained');

    
def cum_var_explained(x1):
    """Plot cumulative variance explained per principal component
    
    Parameters
    ----------
    x1 : numpy array
        The standardized features of the dataset
    """
    X_new, w, variance_explained = pca(x1)
    plt.figure(figsize = (12, 7))
    plt.plot(range(1, len(variance_explained)+1), 
             variance_explained.cumsum(), 'o-', c='red')
    plt.ylim(0,1)
    plt.xlabel('number of PCs')
    plt.ylabel('cumulative variance explained');

    
def plot_pca_comp(components):
    """Plot principal component 1 and 2 of a PCA-transformed matrix
    
    Parameters
    ----------
    components : pandas DataFrame
        The first two principal components of a PCA-transformed matrix   
    """
    plt.figure(figsize=(15,10))
    components_plot = sns.scatterplot(x = 'PC1', y = 'PC2', data=components) 
    components_plot.set_title(label = "NBA Teams \nPrincipal "
                              "Component Analysis")
    components_plot.set(xlabel='Principal Component 1', 
                        ylabel='Principal Component 2')

    #Feature labels
    
    def labelpca(x, y, val, ax):
        df_a = pd.concat({'x': x, 'y': y, 'val': val}, axis=1)
        for i, point in df_a.iterrows():
            ax.text(point['x'], point['y'] + 0.01, str(point['val']))
    labelpca(components.PC1, components.PC2, components.Feature, plt.gca())

    # Add grid lines
    plt.axhline(0, color='grey', linestyle = "--")
    plt.axvline(0, color='grey', linestyle = "--")  

    # Add PCA arrows 
    n = components.shape[0]
    for i in range(n):
        plt.arrow(0, 0, components.PC1[i], components.PC2[i], color = 'red', 
                  alpha = 0.4)
        
        
def label_features(x, y, val, ax):
    """Add labels of features in plot
    
    Parameters
    ----------
    x : pandas Series
       The loadings for PC1

    y : pandas Series
       The loadings for PC2
        
    val : pandas Series
        The features of the principal components
    ax : matplotlib ax
        The ax of the figure being plotted
    """
    
    labels = pd.concat({'x': x, 'y': y, 'val': val}, axis=1)
    for i, point in labels.iterrows():
        ax.text(point['x']-.03, point['y'] + 0.02, str(point['val']), 
                fontsize = 12)
        

def plot_champ_nonchamp_pca(components,x_pca,merged_final1):
    """Plot championship and nonchampionship teams against PC1 and PC2
    
    Parameters
    ----------
    components : pandas DataFrame
        The first two principal components of a PCA-transformed matrix
        
    x_pca : pandas DataFrame
        A PCA-transformed matrix using the standardized features
        
    merged_final1: pandas DataFrame
        The original matrix containing the dataset
    """
    plt.figure(figsize=(15,10))
    plt.scatter(x = components['PC1'], y = components['PC2'], c = "black")

    #PCA arrows
    n = components.shape[0]
    for i in range(n):
        plt.arrow(0, 0,components.PC1[i], components.PC2[i], alpha = 0.35, 
                  fc = "black")

    #Feature labels
    label_features(components.PC1, components.PC2, components.Feature, 
                   plt.gca())

    # Plot PC Scores
    xs = x_pca[:,0]
    ys = x_pca[:,1]
    scalex = 1.0/(xs.max()- xs.min())
    scaley = 1.0/(ys.max()- ys.min())

    champ = [1,0]
    color = ["red",'#D6CFC7'] 
    labellegend = ['Championship Team', 'Non-Championship Team']
    for index in range(len(champ)):
        x_plot = xs[merged_final1["champion_flag"] == champ[index]]
        y_plot = ys[merged_final1["champion_flag"] == champ[index]]
        plt.scatter(x = x_plot*scalex, y = y_plot*scaley,
                   alpha = 0.5, c = color[index], 
                    label = labellegend[index])

    # Grid lines
    plt.axhline(0, color='black', linestyle = "--")
    plt.axvline(0, color='black', linestyle = "--")

    # Labels
    plt.xlabel('Principal Component 1')
    plt.ylabel('Principal Component 2')
    plt.title("NBA Championship vs Non-Championship Teams", fontsize=20, 
              fontweight='bold')
    plt.legend();
    

def plot_modern_champion_pca(components,x_pca,merged_final1):
    """Plot modern champions against old champions against PC1 and PC2
    
    Parameters
    ----------
    components : pandas DataFrame
        The first two principal components of a PCA-transformed matrix
        
    x_pca : pandas DataFrame
        A PCA-transformed matrix using the standardized features
        
    merged_final1: pandas DataFrame
        The original matrix containing the dataset
    """
    plt.figure(figsize=(15,10))
    plt.scatter(x = components['PC1'], y = components['PC2'], c = "black")

    # Add PC arrows
    n = components.shape[0]
    for i in range(n):
        plt.arrow(0, 0,components.PC1[i], components.PC2[i], alpha = 0.35, 
                  fc = "black")

    # Feature labels
    label_features(components.PC1, components.PC2, components.Feature, 
                   plt.gca())

    # Plot PC Scores
    xs = x_pca[:,0]
    ys = x_pca[:,1]
    scalex = 1.0/(xs.max()- xs.min())
    scaley = 1.0/(ys.max()- ys.min())

    x_plot = xs[(merged_final1["champion_flag"] == 1) & 
                (merged_final1.year >= 2010) ]
    y_plot = ys[(merged_final1["champion_flag"] == 1) & 
                (merged_final1.year >= 2010) ]
    plt.scatter(x = x_plot*scalex, y = y_plot*scaley,
               alpha = 0.5, c = 'blue', label = 'Champions on/after 2010')

    x_to_plot2 = xs[(merged_final1["champion_flag"] == 1) & 
                    (merged_final1.year < 2010) ]
    y_to_plot2 = ys[(merged_final1["champion_flag"] == 1) & 
                    (merged_final1.year < 2010) ]
    plt.scatter(x = x_to_plot2*scalex, y = y_to_plot2*scaley, c = 'red', 
                label = 'Champions prior to 2010')

    # Add grid lines
    plt.axhline(0, color='black', linestyle = "--", linewidth = 1.25)
    plt.axvline(0, color='black', linestyle = "--", linewidth = 1.25)

    # Labels
    plt.xlabel('Principal Component 1')
    plt.ylabel('Principal Component 2')
    plt.title("NBA Modern Day Champions vs Old Champions", 
              fontsize=20, fontweight='bold')
    plt.legend();
    

def plot_pca_play_decade(components,x_pca):
    """Plot teams based on decades against PC1 and PC2
    
    Parameters
    ----------
    components : pandas DataFrame
        The first two principal components of a PCA-transformed matrix
        
    x_pca : pandas DataFrame
        A PCA-transformed matrix using the standardized features
        
    merged_final1: pandas DataFrame
        The original matrix containing the dataset
    """
    df_champ = pd.read_csv('NBA_merged_df.csv')
    df_champ['decade'] = (df_champ.year//10)*10
    plt.figure(figsize=(15,10))
    plt.scatter(x = components['PC1'], y = components['PC2'], c = "black")

    # Add PC arrows
    n = components.shape[0]
    for i in range(n):
        plt.arrow(0, 0,components.PC1[i], components.PC2[i], alpha = 0.35, 
                  fc = "black")

    label_features(components.PC1, components.PC2, components.Feature, 
                   plt.gca())

    # Plot PC Scores
    xs = x_pca[:,0]
    ys = x_pca[:,1]
    scalex = 1.0/(xs.max()- xs.min())
    scaley = 1.0/(ys.max()- ys.min())

    decade = [1980, 1990, 2000, 2010, 2020] 
    colors = ["green", "blue", "red", "orange", "yellow"]

    for index in range(len(decade)):
        x_plot = xs[df_champ['decade'] == decade[index]]
        y_plot = ys[df_champ['decade'] == decade[index]]
        plt.scatter(x = x_plot*scalex, y = y_plot*scaley,
                   alpha = 0.5, c = colors[index], label = decade[index])

    # Add grid lines
    plt.axhline(0, color='black', linestyle = "--", linewidth = 1.25)
    plt.axvline(0, color='black', linestyle = "--", linewidth = 1.25)

    # Labels
    plt.xlabel('Principal Component 1')
    plt.ylabel('Principal Component 2')
    plt.title("NBA Play Style Development by the Decade", fontsize=20, 
              fontweight='bold')
    plt.legend();