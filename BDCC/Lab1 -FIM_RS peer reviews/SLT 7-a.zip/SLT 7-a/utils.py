import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
import re
import string
from wordcloud import WordCloud
from matplotlib.colors import ListedColormap, LinearSegmentedColormap
from scipy.spatial import distance
import nltk
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
import warnings
warnings.filterwarnings('ignore')
from surprise import (Reader, Dataset, KNNWithMeans, SVD)
from surprise.model_selection import GridSearchCV


def load_data():
    """Return the dataframes for the raw and transformed and pre-processed
    Jester data and a dataframe for the jokes texts data
    """
    df = pd.read_excel("/mnt/data/public/jester/dataset1/jester-data-1.xls",
                           header=None, na_values=99)
    df2 = pd.read_excel("/mnt/data/public/jester/dataset1/jester-data-2.xls",
                        header=None, na_values=99)
    df3 = pd.read_excel("/mnt/data/public/jester/dataset1/jester-data-3.xls",
                        header=None, na_values=99)
    jokes_df = pd.read_excel("/mnt/data/public/jester/dataset4"
                         "/Dataset4JokeSet.xlsx", header = None)
    df2.index = np.linspace(24983, 48482, 23500, dtype = int)
    df3.index = (np.linspace(48483, 73420, 24938, dtype = int))
    jester_df = df.append([df2, df3])
    jester_df1 = jester_df.drop(0, axis=1)
    jester_df1.replace(np.round(list(np.arange(9, 10.01, 0.01)), 2).tolist(),
                  value=10, inplace = True)
    jester_df1.replace(np.round(list(np.arange(7, 9, 0.01)), 2).tolist(),
                      value=9, inplace = True)
    jester_df1.replace(np.round(list(np.arange(5, 7, 0.01)), 2).tolist(),
                      value=8, inplace = True)
    jester_df1.replace(np.round(list(np.arange(3, 5, 0.01)), 2).tolist(),
                      value=7, inplace = True)
    jester_df1.replace(np.round(list(np.arange(1, 3, 0.01)), 2).tolist(),
                      value=6, inplace = True)
    jester_df1.replace(np.round(list(np.arange(-1, 1, 0.01)), 2).tolist(),
                      value=5, inplace = True)
    jester_df1.replace(np.round(list(np.arange(-3, -1, 0.01)), 2).tolist(),
                      value=4, inplace = True)
    jester_df1.replace(np.round(list(np.arange(-5, -3, 0.01)), 2).tolist(),
                      value=3, inplace = True)
    jester_df1.replace(np.round(list(np.arange(-7, -5, 0.01)), 2).tolist(),
                      value=2, inplace = True)
    jester_df1.replace(np.round(list(np.arange(-9, -7, 0.01)), 2).tolist(),
                      value=1, inplace = True)
    jester_df1.replace(np.round(list(np.arange(-10, -9, 0.01)), 2).tolist(),
                      value=0, inplace = True)
    return jester_df, jokes_df, jester_df1

class color:
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   BLUE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'

    
def get_custom_color_palette_hash():
    """Return a segmented colormap."""
    
    return LinearSegmentedColormap.from_list("", [
        '#282A3E', '#142A8F', '#A466AE',
        '#562434', '#6A533A'
    ])


def decontracted(phrase):
    """Return a text that expands words that are written in shortcut."""
    
    # specific
    phrase = re.sub(r"won't", "will not", phrase)
    phrase = re.sub(r"can\'t", "can not", phrase)

    # general
    phrase = re.sub(r"n\'t", " not", phrase)
    phrase = re.sub(r"\'re", " are", phrase)
    phrase = re.sub(r"\'s", " is", phrase)
    phrase = re.sub(r"\'d", " would", phrase)
    phrase = re.sub(r"\'ll", " will", phrase)
    phrase = re.sub(r"\'t", " not", phrase)
    phrase = re.sub(r"\'ve", " have", phrase)
    phrase = re.sub(r"\'m", " am", phrase)
    return phrase

def plot_mean_rating_dist(jester_df):
    """Plot the distribution of the rating averages."""
    
    jester_df_mean = pd.DataFrame(jester_df.mean(axis = 0))
    jester_df_mean.columns = ['rating']
    df = px.data.tips()
    fig = px.histogram(jester_df_mean, x='rating', nbins=20,
                      title='Histogram of Average Ratings',
                       labels={'rating':'Average Rating',
                              'count':'Count'},
                       color_discrete_sequence=['#282A3E'],
                      text_auto=True)
    fig.update_layout(width=900, height=600, plot_bgcolor='#F5E0E9',
                      title_x=0.5)
    fig.show()

    
def display_top_10_users(jester_df):
    """Displays the 10 users with the highest given rating."""
    
    df_user = (pd.DataFrame(jester_df.reset_index()
                        .melt('index').set_index('index')['value']))
    df_user_ave_rating = df_user.groupby(df_user.index).mean()
    top_10 = (df_user_ave_rating.sort_values('value', ascending=False,
                                             kind="mergesort")[:10])
    top_10 = top_10.reset_index()
    top_10.columns = (['user','value'])
    return top_10


def display_least_10_users(jester_df):
    """Return the 10 users with the lowest given rating."""
    
    df_user = (pd.DataFrame(jester_df.reset_index()
                    .melt('index').set_index('index')['value']))
    df_user_ave_rating = df_user.groupby(df_user.index).mean()
    bottom_10 = (df_user_ave_rating.sort_values('value', ascending=True,
                                             kind="mergesort")[:10])
    bottom_10 = bottom_10.reset_index()
    bottom_10.columns = (['user','value'])
    return bottom_10


def display_top_jokes(jester_df, jokes_df, n=10):
    """Return the texts of the top n jokes."""
    
    jester_df_mean = pd.DataFrame(jester_df.mean(axis = 0))
    jester_df_mean.columns = ['rating']
    top_jokes_ind = list(jester_df_mean.sort_values('rating', ascending=False,
                                    kind='mergesort')[:n].index)
    top_10_jokes_text = jokes_df.loc[top_jokes_ind].values.tolist()
    for index, i in enumerate(top_10_jokes_text):
        print(color.BOLD + f"Top {index+1}: " + color.END, i[0])
        print("")


def wordcloud_top_n_jokes(jester_df, jokes_df, n=10):
    """Plot into WordCloud the most frequent texts in the top jokes."""
    
    idx = jester_df.mean().sort_values(ascending=False).index
    top_idx = idx[:n]
    top_jokes = jokes_df.iloc[top_idx]
    top_jokes.loc[:, 0] = top_jokes.loc[:, 0].apply(decontracted)
    filtered_words = preprocess_text(top_jokes)
    top_jokes['clean_tokenize'] = filtered_words
    top_jokes['clean'] = top_jokes.clean_tokenize.apply(' '.join)
    text = ' '.join(top_jokes['clean'])
    
    wordcloud2 = WordCloud(background_color='#F5E0E9', 
                           colormap=get_custom_color_palette_hash(),
                           width = 1500,
                           height = 800).generate(text)
    # Generate plot
    fig, ax = plt.subplots(1, 1, figsize=(20, 15))
    plt.imshow(wordcloud2)
    plt.axis("off")
    plt.show()
    

def display_bottom_jokes(jester_df, jokes_df, n=10):
    """Return the texts of the bottom n jokes."""
    jester_df_mean = pd.DataFrame(jester_df.mean(axis = 0))
    jester_df_mean.columns = ['rating']
    bottom_jokes_ind = list(jester_df_mean.sort_values('rating', 
                                                       ascending=True,
                                    kind='mergesort')[:n].index)
    bottom_10_jokes_text = jokes_df.loc[bottom_jokes_ind].values.tolist()
    for index, i in enumerate(bottom_10_jokes_text):
        print(color.BOLD + f"Bottom {100-index}: " + color.END, i[0])
        print("")
        

def wordcloud_bottom_n_jokes(jester_df, jokes_df, n=10):
    """Plot into WordCloud the most frequent texts in the bottom jokes."""
    idx = jester_df.mean().sort_values(ascending=False).index
    bottom_idx = idx[-n:]
    bottom_jokes = jokes_df.iloc[bottom_idx]
    bottom_jokes.loc[:, 0] = bottom_jokes.loc[:, 0].apply(decontracted)
    filtered_words = preprocess_text(bottom_jokes)
    bottom_jokes['clean_tokenize'] = filtered_words
    bottom_jokes['clean'] = bottom_jokes.clean_tokenize.apply(' '.join)
    text = ' '.join(bottom_jokes['clean'])
    
    wordcloud2 = WordCloud(background_color='#F5E0E9', 
                           colormap=get_custom_color_palette_hash(),
                           width = 1500,
                           height = 800).generate(text)
    # Generate plot
    fig, ax = plt.subplots(1, 1, figsize=(20, 15))
    plt.imshow(wordcloud2)
    plt.axis("off")
    plt.show()


def user_top_jokes(jester_df, jokes_df, n, user):
    """Return the texts of the top n joke of a user."""
    
    jester_df_mean = jester_df.reset_index().groupby('index').mean()
    list_ind = list(pd.DataFrame(jester_df_mean.loc[user]).sort_values(user,
                                                 ascending = False)[:n].index)
    for index, i in enumerate(jokes_df.loc[list_ind][0]):
        print(color.BOLD + f"Top {index+1}: " + color.END, i)
        print("")

        
def calc_weighted_ave(top_users_mat, top_users_similarity):
    """Calculate the weighted average of common ratings with
    similarity scores as weights"""
    
    num = top_users_mat.mul(top_users_similarity, axis=0).sum()
    den = np.array(top_users_similarity.fillna(0)) @\
          np.array(top_users_mat.notnull().astype(int))
    
    return num/den


def not_nan(a, b):
        """Return only the common non-NA items between to matrices."""
        ind = ~a.isna() & ~b.isna()
        return a[ind], b[ind]
    

def user_recommend(user, jokes_df, df_utility, k=5):
    ind = user
    k = k

    df_utility = df_utility.reset_index().groupby('index').mean()
    means = df_utility.mean(axis=1)
    df_utility_mc = df_utility.sub(means, axis=0)
    
    U = df_utility_mc.loc[ind]
    I = df_utility_mc.drop(ind)
    user_mat = df_utility.loc[[ind]]
    
    distances = I.apply(lambda x: distance.cosine(*not_nan(x, U)) if 
                        (len(not_nan(x, U)[0]) != 0) & 
                        (len(not_nan(x, U)[1]) != 0) else np.nan, axis=1)
    cossim = 1 - distances
    user_cossim = pd.DataFrame(cossim).sort_values([0,'index'], 
                                                   ascending=[False, True],
                                                  kind='mergesort')[:k]
    user_cossim = user_cossim[0]
    
    
    
    similar_users = df_utility_mc.loc[user_cossim.index]
    rated_items = df_utility_mc.loc[ind].dropna().index.tolist()
    unrated_items = df_utility_mc.columns.difference(rated_items).tolist()
    top_users = similar_users[unrated_items]
    
    weighted_ave = calc_weighted_ave(top_users, user_cossim)
    
    # Getting normalized rating
    true_rating = weighted_ave + means.loc[ind]
    user_mat.loc[ind, unrated_items] = true_rating
    user_mat_trans = user_mat[unrated_items].T.reset_index()
    user_mat_trans.columns = ['Jokes', 'Ratings']
    list_ind = list(user_mat_trans.sort_values(['Ratings', 'Jokes'],
                                            ascending=[False, True],
                                            kind='mergesort')['Jokes'][:5])

    jokes_list = jokes_df.loc[list_ind].values.tolist()
    for index, i in enumerate(jokes_list):
        print(color.BOLD + f"Recommended Joke {index+1}: " + color.END, i[0])
        print("")
        

def preprocess_text(df):
    """Return the cleaned and preprocessed texts of the jokes."""
    
    # tokenize
    tokenize = df.loc[:,0].apply(nltk.word_tokenize)

    # casefold
    lower_case = tokenize.apply(lambda x: 
                               list(map(lambda y: y.casefold(), x)))
    
    
    # lemmatize
    lemmatizer = WordNetLemmatizer()
    lemmatize = lower_case.apply(lambda x: list(map(lemmatizer.lemmatize, 
                                                             x)))

    # remove stopwords
    stop_words = list(set(stopwords.words('english')))
    filtered_stopwords = lemmatize.apply(lambda x: 
                                         list(filter(lambda y:y not in 
                                                     stop_words, 
                                                     x)))

    # filter words with less than 3 character length
    filtered_words = filtered_stopwords.apply(lambda x: 
                                             list(filter(lambda y:len(y) 
                                                         > 3, x)))

    return filtered_words


def fit_svd(jester_df):
    """Fit dataset to SVD
    """
    df_utility = jester_df.copy()

    reader = Reader(rating_scale=(0,10))

    df_melt = (
        df_utility
        .reset_index()
        .melt('index', var_name='itemID', value_name='rating')
        .dropna()
    )

    dataset = Dataset.load_from_df(df_melt, reader)

    svd = SVD(n_epochs=10, lr_all=0.002, reg_all=0.4, random_state=1337)
    svd.fit(dataset.build_full_trainset())
    
    return svd


def user_recommend_svd(uid,
                       top_n,
                       svd,
                       jester_df,
                       jokes_df):
    """Provided recommended jokes based on Surprise's SVD
    """
    df_utility = jester_df.copy()

    df_melt = (
        df_utility
        .reset_index()
        .melt('index', var_name='itemID', value_name='rating')
        .dropna()
    )

    items = set(df_melt['itemID'].values)
    user_rated_items = set(df_melt[df_melt['index'] == uid]['itemID'])
    user_non_rated_items = list(items - user_rated_items)

    est_ratings = (
        [(ind, svd.predict(uid, ind).est) for ind in user_non_rated_items]
    )
    top_items = (
        [x[0] for x in sorted(est_ratings, key=lambda x: (-x[1], x[0]))]
    )
    print(top_items)
    print("Surprise's Recommendations for User ", uid, ":")
    for n in range(top_n):
        print(f"Recommended Joke {n + 1} :", jokes_df.iloc[top_items[n]][0])

        
def train_svd(jester_df):

    df_utility = jester_df.copy()

    reader = Reader(rating_scale=(0,10))

    df_melt = (
        df_utility
        .reset_index()
        .melt('index', var_name='itemID', value_name='rating')
        .dropna()
    )

    dataset = Dataset.load_from_df(df_melt, reader)

    # Parameters
    param_grid = {
    'n_epochs': [20],
    'lr_all': [0.002, 0.005, 0.01],
    'reg_all': [0.4, 0.6, 0.8]
    }
    
    # GridSearch
    gs = GridSearchCV(
        SVD, param_grid, measures=['rmse'], joblib_verbose=10, cv=3
    )
    
    # Fit into dataset
    gs.fit(dataset)
    print(gs.best_score['rmse'])
    print(gs.best_params['rmse'])
